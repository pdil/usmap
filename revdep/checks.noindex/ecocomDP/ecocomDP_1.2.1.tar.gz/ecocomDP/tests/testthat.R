library(testthat)
library(ecocomDP)

test_check("ecocomDP")
