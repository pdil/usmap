library(testthat)
library(refuge)

test_check("refuge")
