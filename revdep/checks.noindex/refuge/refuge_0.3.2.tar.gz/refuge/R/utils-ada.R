

ada_function <- function(accessible) {
  if (accessible == TRUE) {
    "ada=true&"
  } else {
    ""
  }
}
