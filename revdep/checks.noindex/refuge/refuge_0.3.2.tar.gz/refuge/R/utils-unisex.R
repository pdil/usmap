

unisex_function <- function(unisex) {
  if (unisex == TRUE) {
    "unisex=true&"
  } else {
    ""
  }
}
