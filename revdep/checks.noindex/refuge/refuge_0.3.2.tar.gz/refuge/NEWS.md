
# refuge 0.3.2

* Fixed errors in `rfg_search` function.

# refuge 0.3.0

* Fixed test errors found on CRAN.

* Added `updated` parameter to `rfg_date`. Please check your code as this may
break existing workflows.

# refuge 0.2.0

* Improved internal function called by the optional `tidy` parameter so 
uncorrected state names are returned as their original value, rather than `NA`.

* Switched to `usmap` package in the vignette, as the previous package used for
the map of the USA has been archived on CRAN.

# refuge 0.1.2

* Added optional `tidy` parameter

# refuge 0.1.1

* Release of complete package to CRAN

* Added a `NEWS.md` file to track changes to the package.
